from pathlib import Path
import csv
import pytest
from chatbot.engine import (ChatbotEngine, load_themes, preprocess, similarity, validate_theme)

BASE = Path(__file__).resolve().parent.parent
THEMES = load_themes(BASE / "themes")
engine = ChatbotEngine(THEMES["hardware"])


def test_preprocess_normalisasi_dan_stopword():
    assert preprocess("Gmn cara BAYAR, dong?") == ["bagaimana", "cara", "bayar"]
    assert preprocess("vga") == ["gpu"] and preprocess("kartu grafis") == ["gpu"]


def test_preprocess_menjaga_token_alfanumerik():
    assert "rtx" in preprocess("RTX 4060") and "4060" in preprocess("RTX 4060")
    assert "i5" in preprocess("Core i5")


def test_similarity_kalimat_sama_bernilai_satu():
    t = preprocess("cek bottleneck")
    assert similarity(t, t) == pytest.approx(1.0)


def test_similarity_kalimat_beda_rendah():
    assert similarity(preprocess("resep nasi goreng"), preprocess("cek bottleneck")) < 0.45


@pytest.mark.parametrize("pesan,tag", [
    ("halo", "salam"),
    ("rekomendasi rakit pc 8 juta buat main game", "rakit_budget"),
    ("mending upgrade ram atau ssd dulu", "upgrade_prioritas"),
    ("cpu bottleneck gak sama gpu", "bottleneck"),
    ("cek kompatibilitas mobo sama ram", "kompatibilitas"),
    ("kenapa valorant stuttering padahal fps tinggi", "fps_stutter"),
    ("cara setting refresh rate layar", "refresh_rate"),
    ("seberapa penting vram buat game", "vram"),
    ("butuh psu berapa watt", "psu_wattage"),
])
def test_klasifikasi_intent(pesan, tag):
    assert engine.classify(pesan)[0] == tag


def test_salah_ketik_masih_dikenali():
    assert engine.classify("game stuterring")[0] == "fps_stutter"


def test_pertanyaan_di_luar_tema_memberi_fallback():
    r = engine.reply("siapa presiden indonesia")
    assert r["intent"] is None and r["reply"] in THEMES["hardware"]["fallback"]


def test_placeholder_nama_bot_diganti():
    assert "{nama_bot}" not in engine.reply("halo")["reply"]
    assert "RigMate" in engine.greeting()


def test_explain_mengurutkan_dari_skor_tertinggi():
    c = engine.explain("cek bottleneck")
    assert len(c) == 3 and c[0]["score"] >= c[1]["score"] >= c[2]["score"]


def test_validate_theme_menemukan_kesalahan():
    assert validate_theme({"id": "x"}) != []


def test_semua_tema_valid_dan_cukup_intent():
    for t in THEMES.values():
        assert validate_theme(t) == []
    assert len(THEMES["hardware"]["intents"]) >= 10


def test_akurasi_data_uji_minimal_90_persen():
    with open(BASE / "evaluasi" / "hardware.csv", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))
    benar = sum((engine.classify(r["kalimat"])[0] or "fallback") == r["intent"] for r in rows)
    assert benar / len(rows) >= 0.90
