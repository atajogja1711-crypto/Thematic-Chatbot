import pytest
from app import create_app


@pytest.fixture
def client(tmp_path):
    app = create_app({"TESTING": True, "DATABASE": str(tmp_path / "t.db")})
    return app.test_client()


def test_halaman_utama_menampilkan_tema(client):
    r = client.get("/")
    assert r.status_code == 200 and b"RigMate" in r.data


def test_halaman_chat(client):
    assert client.get("/chat/hardware").status_code == 200


def test_tema_tidak_ada_404(client):
    assert client.get("/chat/tidak-ada").status_code == 404
    assert client.get("/api/history/tidak-ada").status_code == 404


def test_api_themes(client):
    assert client.get("/api/themes").get_json()[0]["id"] == "hardware"


def test_api_chat_berhasil(client):
    r = client.post("/api/chat", json={"message": "halo", "theme": "hardware"})
    d = r.get_json()
    assert r.status_code == 200 and d["intent"] == "salam" and d["reply"]


@pytest.mark.parametrize("payload", [
    {"message": ""}, {"message": "   "}, {"message": "x" * 501}, {"message": "halo", "theme": "ngawur"},
])
def test_api_chat_input_tidak_valid(client, payload):
    assert client.post("/api/chat", json=payload).status_code == 400


def test_api_chat_body_bukan_json(client):
    assert client.post("/api/chat", data="halo").status_code == 400


def test_riwayat_tersimpan_dan_bisa_dihapus(client):
    client.post("/api/chat", json={"message": "halo", "theme": "hardware"})
    assert len(client.get("/api/history/hardware").get_json()) == 2
    client.delete("/api/history/hardware")
    assert client.get("/api/history/hardware").get_json() == []


def test_statistik_intent(client):
    client.post("/api/chat", json={"message": "halo", "theme": "hardware"})
    assert client.get("/api/stats/hardware").get_json()[0]["intent"] == "salam"


def test_api_explain(client):
    r = client.post("/api/explain", json={"message": "cek bottleneck", "theme": "hardware"})
    assert len(r.get_json()["candidates"]) == 3


def test_admin_menampilkan_pertanyaan_tak_dikenali(client):
    client.post("/api/chat", json={"message": "harga bensin berapa", "theme": "hardware"})
    r = client.get("/admin/hardware")
    assert r.status_code == 200 and b"harga bensin berapa" in r.data


def test_admin_key_melindungi_halaman(tmp_path):
    app = create_app({"TESTING": True, "DATABASE": str(tmp_path / "t.db"), "ADMIN_KEY": "rahasia"})
    c = app.test_client()
    assert c.get("/admin/hardware").status_code == 403
    assert c.get("/admin/hardware?key=rahasia").status_code == 200


def test_xss_di_admin_di_escape(client):
    client.post("/api/chat", json={"message": "<script>alert(1)</script>", "theme": "hardware"})
    assert b"<script>alert(1)</script>" not in client.get("/admin/hardware").data
