"""Ukur akurasi: python evaluate.py --tema hardware [--sweep]"""
import argparse
import csv
from pathlib import Path

from chatbot.engine import ChatbotEngine, load_themes

BASE = Path(__file__).parent


def evaluasi(engine, rows):
    salah = []
    for kalimat, harapan in rows:
        tag, skor = engine.classify(kalimat)
        if (tag or "fallback") != harapan:
            salah.append((kalimat, harapan, tag or "fallback", skor))
    return 100 * (len(rows) - len(salah)) / len(rows), salah


ap = argparse.ArgumentParser()
ap.add_argument("--tema", default="hardware")
ap.add_argument("--sweep", action="store_true", help="bandingkan beberapa ambang")
args = ap.parse_args()

theme = load_themes(BASE / "themes")[args.tema]
with open(BASE / "evaluasi" / f"{args.tema}.csv", encoding="utf-8") as f:
    rows = [(r["kalimat"], r["intent"]) for r in csv.DictReader(f)]

if args.sweep:
    for th in (0.30, 0.35, 0.40, 0.45, 0.50, 0.55, 0.60, 0.70):
        acc, _ = evaluasi(ChatbotEngine(theme, th), rows)
        print(f"ambang {th:.2f}  akurasi {acc:5.1f}%")
else:
    acc, salah = evaluasi(ChatbotEngine(theme), rows)
    print(f"Tema {args.tema}: {len(rows) - len(salah)} benar dari {len(rows)} = {acc:.1f}%")
    for k, h, t, s in salah:
        print(f"  SALAH: '{k}' harapan={h} tebakan={t} skor={s:.2f}")
