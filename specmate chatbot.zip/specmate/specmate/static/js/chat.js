// Antarmuka chat: fetch() ke REST API tanpa memuat ulang halaman.
// Semua teks ditampilkan dengan textContent (bukan innerHTML) agar aman dari XSS.
(() => {
  const root = document.getElementById("chat");
  const theme = root.dataset.theme;
  const box = document.getElementById("messages");
  const form = document.getElementById("chat-form");
  const input = document.getElementById("chat-input");
  const learn = document.getElementById("learn-mode");

  function addMessage(who, text, meta) {
    const div = document.createElement("div");
    div.className = "msg msg-" + who;
    div.textContent = text;
    if (meta) {
      const m = document.createElement("small");
      m.className = "meta";
      m.textContent = meta;
      div.appendChild(m);
    }
    box.appendChild(div);
    box.scrollTop = box.scrollHeight;
    return div;
  }

  const metaOf = (intent, score) =>
    `intent: ${intent || "tidak dikenali"} · skor ${Number(score).toFixed(2)}`;

  async function post(url, text) {
    const res = await fetch(url, {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify({message: text, theme}),
    });
    return {ok: res.ok, data: await res.json()};
  }

  async function sendMessage(text) {
    addMessage("user", text);
    const typing = addMessage("bot", "…");
    try {
      const {ok, data} = await post("/api/chat", text);
      if (!ok) { typing.textContent = data.error; return; }
      typing.remove();
      addMessage("bot", data.reply, metaOf(data.intent, data.score));
      if (learn.checked) {
        const ex = await post("/api/explain", text);
        if (ex.ok) {
          const lines = ex.data.candidates.map((c, i) =>
            `${i + 1}. ${c.intent} · ${c.score.toFixed(2)} (${c.passed ? "lolos" : "di bawah"} ambang) — pola "${c.pattern}"`);
          const last = box.lastChild;
          const m = document.createElement("small");
          m.className = "meta";
          m.textContent = lines.join("\n");
          last.appendChild(m);
        }
      }
    } catch (err) {
      typing.textContent = "Gagal terhubung ke server.";
    }
  }

  form.addEventListener("submit", (e) => {
    e.preventDefault();               // jangan muat ulang halaman
    const text = input.value.trim();
    if (!text) return;                // pesan kosong tidak dikirim
    input.value = "";
    sendMessage(text);
  });

  function renderChips() {
    const chips = document.getElementById("chips");
    chips.replaceChildren();
    JSON.parse(root.dataset.suggestions).forEach((s) => {
      const b = document.createElement("button");
      b.type = "button";
      b.textContent = s;
      b.addEventListener("click", () => sendMessage(s));
      chips.appendChild(b);
    });
  }

  async function loadHistory() {
    box.replaceChildren();
    try {
      const rows = await (await fetch("/api/history/" + theme)).json();
      if (rows.length === 0) { addMessage("bot", root.dataset.greeting); return; }
      rows.forEach((r) => addMessage(r.sender, r.text,
        r.sender === "bot" ? metaOf(r.intent, r.score) : null));
    } catch (err) {
      addMessage("bot", root.dataset.greeting);
    }
  }

  document.getElementById("clear-btn").addEventListener("click", async () => {
    await fetch("/api/history/" + theme, {method: "DELETE"});
    loadHistory();
  });

  renderChips();
  loadHistory();
})();
