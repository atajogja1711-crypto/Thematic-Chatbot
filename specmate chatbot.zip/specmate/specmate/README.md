# SpecMate (RigMate) — Chatbot Tematik Hardware PC dengan Flask

Pemilik: Ilham Syawal Alfata (24051130015)

## 1. Cara menjalankan (±5 menit)

Prasyarat: Python 3.10+ (cek: `python --version`).

```bash
cd specmate
python -m venv venv

# aktifkan venv
venv\Scripts\activate            # Windows (PowerShell menolak? jalankan sekali:
                                 #   Set-ExecutionPolicy -Scope CurrentUser RemoteSigned)
source venv/bin/activate         # macOS / Linux

pip install -r requirements.txt
```

| Tujuan | Perintah |
|---|---|
| Coba bot di terminal | `python cli.py --debug` |
| Jalankan semua uji (harus 36 passed) | `pytest -v` |
| Ukur akurasi | `python evaluate.py` |
| Bandingkan ambang | `python evaluate.py --sweep` |
| Jalankan web | `python app.py` lalu buka http://127.0.0.1:5000 |

Variabel lingkungan (opsional): `SECRET_KEY`, `ADMIN_KEY`, `THRESHOLD` (bawaan 0.45), `DATABASE`.

## 2. Urutan implementasi (ikuti agar paham tiap lapisan)

Kerjakan berurutan dan jalankan `pytest -v` setiap selesai satu langkah.

| Langkah | Yang dikerjakan | File | Cara memeriksa |
|---|---|---|---|
| 1 | Siapkan venv dan pasang Flask | `requirements.txt` | `python -c "import flask"` tanpa galat |
| 2 | Tulis pengetahuan bot (intent, pola, respons) | `themes/hardware.json` | `python -c "from chatbot.engine import *; print(validate_theme(load_themes('themes')['hardware']))"` menampilkan `[]` |
| 3 | Tulis mesin: `preprocess`, `similarity`, `classify`, `reply` | `chatbot/engine.py` | `python cli.py --debug` |
| 4 | Tulis uji mesin | `tests/test_engine.py` | `pytest tests/test_engine.py -v` |
| 5 | Tulis penyimpanan riwayat SQLite | `chatbot/database.py` | dicek lewat `test_app.py` |
| 6 | Tulis route halaman dan REST API | `app.py` | `pytest tests/test_app.py -v` |
| 7 | Tulis template, CSS, dan `chat.js` | `templates/`, `static/` | buka di browser |
| 8 | Buat data uji dan ukur akurasi | `evaluasi/hardware.csv`, `evaluate.py` | `python evaluate.py` (target ≥ 90%) |
| 9 | Uji coba dengan 3 teman, lihat halaman `/admin/hardware` | — | catat pertanyaan yang gagal |
| 10 | Tambah pola dari pertanyaan gagal, ulangi langkah 8 | `themes/hardware.json` | akurasi naik |

## 3. Peta berkas

```
app.py                 route halaman + REST API + admin (application factory)
cli.py                 chat di terminal, --debug menampilkan 3 kandidat dan skor
evaluate.py            akurasi dan sweep ambang
chatbot/engine.py      praproses, skor kemiripan, keputusan, jawaban (tanpa Flask)
chatbot/database.py    riwayat dan statistik SQLite
themes/hardware.json   seluruh pengetahuan bot
evaluasi/hardware.csv  data uji (kalimat,intent)
templates/ static/     tampilan
tests/                 36 uji pytest
```

## 4. Cara kerja mesin (ringkas)

1. `preprocess`: huruf kecil, ganti frasa (`kartu grafis` → `gpu`), buang tanda baca, normalisasi (`gmn` → `bagaimana`), buang stopword.
2. `similarity`: `skor = 0,4 × Jaccard + 0,3 × Fuzzy + 0,3 × Cakupan`.
3. `classify`: ambil pola dengan skor tertinggi; jika skor < 0,45 maka fallback.
4. `reply`: pilih respons acak, isi placeholder `{nama_bot}`, `{waktu}`, `{tanggal}`.

Angka `1`–`4` dari menu sapaan juga dikenali (pola di intent `rakit_budget`, `bottleneck`, `fps_stutter`, `benchmark`).

## 5. API

| Metode | URL | Keterangan |
|---|---|---|
| GET | `/`, `/chat/<tema>`, `/admin/<tema>` | halaman HTML |
| GET | `/api/themes` | daftar tema |
| POST | `/api/chat` | body `{"message": "...", "theme": "hardware"}` → `{"intent","reply","score"}` |
| POST | `/api/explain` | tiga kandidat intent teratas |
| GET / DELETE | `/api/history/<tema>` | riwayat sesi ini |
| GET | `/api/stats/<tema>` | jumlah pertanyaan per intent |

Uji cepat API (server harus berjalan):

```bash
curl -X POST http://127.0.0.1:5000/api/chat -H "Content-Type: application/json" \
     -d '{"message":"kenapa valorant stuttering padahal fps tinggi","theme":"hardware"}'
```

Kode status: 200 berhasil · 400 input salah · 403 kunci admin salah · 404 tema tidak ada.

## 6. Menambah dan memperbaiki pengetahuan

1. Buka `http://127.0.0.1:5000/admin/hardware` dan lihat pertanyaan yang tidak dikenali.
2. Salin kalimatnya sebagai pola baru pada intent yang sesuai di `themes/hardware.json`.
3. Jika bot salah memilih intent, jalankan `python cli.py --debug` dan lihat pola mana yang menang, lalu perbaiki pola atau kamus `NORMALISASI` di `engine.py`.
4. Tambahkan kalimat tersebut ke `evaluasi/hardware.csv` bila belum ada, lalu jalankan `pytest -v` dan `python evaluate.py`.
5. Restart `python app.py` (tema dimuat saat start).

Aturan kualitas: 5–8 pola per intent dengan kata yang benar-benar dipakai orang, minimal 2 respons per intent, jawaban singkat dan tidak memuat harga atau angka yang cepat kedaluwarsa.

## 7. Checklist tugas (rubrik)

- [ ] Aplikasi berjalan tanpa galat, semua halaman terbuka (15%)
- [ ] `themes/hardware.json`: ≥ 10 intent, ≥ 5 pola dan 2 respons per intent, 4 saran (25%). Sudah 16 intent. Periksa jumlah pola per intent sebelum dikumpulkan.
- [ ] ≥ 8 kasus uji tema, semua lolos (15%)
- [ ] ≥ 10 kata di `NORMALISASI`, semuanya relevan dengan hardware (sudah ada; tambahkan milik Anda sendiri)
- [ ] `evaluasi/hardware.csv` ≥ 20 kalimat + uji coba 3 teman; laporkan akurasi sebelum dan sesudah perbaikan (15%)
- [ ] Satu fitur pengembangan, misalnya intent berkonteks atau TF-IDF (20%)
- [ ] Laporan PDF maksimal 5 halaman (10%)

Dikumpulkan: ZIP proyek (tanpa `venv/` dan `*.db`) + laporan PDF.

## 8. Ide tugas pengembangan (pilih satu)

- **Intent berkonteks:** simpan intent terakhir per sesi; tambahkan kunci `"next"` di JSON agar bot bertanya lanjutan (misalnya setelah `rakit_budget`, tanya penggunaan game).
- **Ekstraksi budget:** regex `(\d+)\s*(juta|jt)` untuk menangkap angka budget dan memasukkannya ke respons.
- **TF-IDF + cosine similarity:** bandingkan akurasinya dengan skor 0,4/0,3/0,3 memakai `evaluate.py`.
- **Grafik di admin:** tampilkan statistik intent dengan Chart.js.

## 9. Deployment

```bash
set SECRET_KEY=isi-acak-panjang   # Windows (Linux/macOS: export ...)
set ADMIN_KEY=kunci-admin
waitress-serve --port=8000 app:app       # Windows/Linux
# gunicorn -w 2 -b 0.0.0.0:8000 app:app  # Linux
```

Pastikan `debug` mati, `SECRET_KEY` dan `ADMIN_KEY` diisi, dan `chat_history.db` dicadangkan berkala.

## 10. Masalah umum

| Gejala | Penyebab dan solusi |
|---|---|
| `ModuleNotFoundError: flask` | venv belum aktif atau `pip install -r requirements.txt` belum dijalankan |
| `ModuleNotFoundError: chatbot` saat `pytest` | jalankan dari folder `specmate/` (ada `pytest.ini`) |
| Perubahan JSON tidak muncul | restart `python app.py` |
| Bot salah menjawab | `python cli.py --debug`, lihat kandidat dan skornya |
| Port 5000 dipakai | ganti dengan `app.run(port=5001)` |
