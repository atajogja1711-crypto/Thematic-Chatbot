"""Flask: halaman, REST API, sesi, dan admin. Logika chatbot ada di chatbot/engine.py."""
import os
import uuid
from pathlib import Path

from flask import Flask, jsonify, render_template, request, session

from chatbot.database import ChatHistory
from chatbot.engine import ChatbotEngine, load_themes

BASE = Path(__file__).parent
MAX_LEN = 500


def create_app(config=None):
    app = Flask(__name__)
    app.config.update(
        SECRET_KEY=os.environ.get("SECRET_KEY", "dev-ganti-di-produksi"),
        THRESHOLD=float(os.environ.get("THRESHOLD", "0.45")),
        DATABASE=os.environ.get("DATABASE", str(BASE / "chat_history.db")),
        ADMIN_KEY=os.environ.get("ADMIN_KEY", ""),
        THEMES_DIR=str(BASE / "themes"),
    )
    if config:
        app.config.update(config)

    themes = load_themes(app.config["THEMES_DIR"])
    engines = {tid: ChatbotEngine(t, app.config["THRESHOLD"]) for tid, t in themes.items()}
    history = ChatHistory(app.config["DATABASE"])

    def get_session_id():
        if "sid" not in session:
            session["sid"] = uuid.uuid4().hex
        return session["sid"]

    def galat(pesan, kode=400):
        return jsonify({"error": pesan}), kode

    def read_message():
        """Validasi body JSON; kembalikan (theme_id, message, error_response)."""
        data = request.get_json(silent=True)
        if not isinstance(data, dict):
            return None, None, galat("Body harus berformat JSON")
        theme_id = data.get("theme", next(iter(themes)))
        if theme_id not in engines:
            return None, None, galat("Tema tidak ditemukan")
        message = str(data.get("message", "")).strip()
        if not message:
            return None, None, galat("Pesan tidak boleh kosong")
        if len(message) > MAX_LEN:
            return None, None, galat(f"Pesan maksimal {MAX_LEN} karakter")
        return theme_id, message, None

    # ---------- halaman HTML ----------
    @app.get("/")
    def index():
        return render_template("index.html", themes=list(themes.values()))

    @app.get("/chat/<theme_id>")
    def chat_page(theme_id):
        if theme_id not in themes:
            return render_template("404.html"), 404
        return render_template("chat.html", theme=themes[theme_id],
                               greeting=engines[theme_id].greeting())

    @app.get("/admin/<theme_id>")
    def admin_page(theme_id):
        if theme_id not in themes:
            return render_template("404.html"), 404
        key = app.config["ADMIN_KEY"]
        if key and request.args.get("key") != key:
            return "Kunci admin salah.", 403
        return render_template("admin.html", theme=themes[theme_id],
                               summary=history.summary(theme_id),
                               stats=history.stats(theme_id),
                               unknown=history.unknown(theme_id),
                               threshold=app.config["THRESHOLD"])

    # ---------- REST API ----------
    @app.get("/api/themes")
    def api_themes():
        return jsonify([{"id": t["id"], "bot_name": t["bot_name"], "title": t["title"]}
                        for t in themes.values()])

    @app.post("/api/chat")
    def api_chat():
        theme_id, message, err = read_message()
        if err:
            return err
        sid = get_session_id()
        result = engines[theme_id].reply(message)
        history.add(sid, theme_id, "user", message, result["intent"], result["score"])
        history.add(sid, theme_id, "bot", result["reply"], result["intent"], result["score"])
        return jsonify(result)

    @app.post("/api/explain")
    def api_explain():
        theme_id, message, err = read_message()
        if err:
            return err
        return jsonify({"candidates": engines[theme_id].explain(message)})

    @app.get("/api/history/<theme_id>")
    def api_history(theme_id):
        if theme_id not in themes:
            return galat("Tema tidak ditemukan", 404)
        return jsonify(history.history(get_session_id(), theme_id))

    @app.delete("/api/history/<theme_id>")
    def api_history_delete(theme_id):
        if theme_id not in themes:
            return galat("Tema tidak ditemukan", 404)
        history.clear(get_session_id(), theme_id)
        return jsonify({"deleted": True})

    @app.get("/api/stats/<theme_id>")
    def api_stats(theme_id):
        if theme_id not in themes:
            return galat("Tema tidak ditemukan", 404)
        return jsonify(history.stats(theme_id))

    return app


app = create_app()

if __name__ == "__main__":
    app.run(debug=True)  # debug=True hanya untuk komputer sendiri
