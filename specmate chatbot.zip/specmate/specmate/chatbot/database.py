"""Riwayat percakapan dan statistik di SQLite. Semua nilai lewat parameter '?'."""
import sqlite3
from contextlib import closing

SCHEMA = """
CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL,
    theme TEXT NOT NULL,
    sender TEXT NOT NULL,
    text TEXT NOT NULL,
    intent TEXT,
    score REAL,
    created_at TIMESTAMP DEFAULT (datetime('now', 'localtime'))
)"""


class ChatHistory:
    def __init__(self, path):
        self.path = path
        with closing(self._conn()) as conn, conn:
            conn.execute(SCHEMA)

    def _conn(self):
        conn = sqlite3.connect(self.path)
        conn.row_factory = sqlite3.Row
        return conn

    def add(self, session_id, theme, sender, text, intent=None, score=None):
        with closing(self._conn()) as conn, conn:
            conn.execute(
                "INSERT INTO messages (session_id, theme, sender, text, intent, score) "
                "VALUES (?, ?, ?, ?, ?, ?)", (session_id, theme, sender, text, intent, score))

    def history(self, session_id, theme):
        with closing(self._conn()) as conn:
            rows = conn.execute(
                "SELECT sender, text, intent, score FROM messages "
                "WHERE session_id = ? AND theme = ? ORDER BY id", (session_id, theme))
            return [dict(r) for r in rows]

    def clear(self, session_id, theme):
        with closing(self._conn()) as conn, conn:
            conn.execute("DELETE FROM messages WHERE session_id = ? AND theme = ?",
                         (session_id, theme))

    def stats(self, theme):
        with closing(self._conn()) as conn:
            rows = conn.execute(
                "SELECT COALESCE(intent, '(tidak dikenali)') AS intent, COUNT(*) AS jumlah "
                "FROM messages WHERE theme = ? AND sender = 'user' "
                "GROUP BY intent ORDER BY 2 DESC", (theme,))
            return [dict(r) for r in rows]

    def unknown(self, theme, limit=20):
        with closing(self._conn()) as conn:
            rows = conn.execute(
                "SELECT text, score, created_at FROM messages "
                "WHERE theme = ? AND sender = 'user' AND intent IS NULL "
                "ORDER BY id DESC LIMIT ?", (theme, limit))
            return [dict(r) for r in rows]

    def summary(self, theme):
        with closing(self._conn()) as conn:
            r = conn.execute(
                "SELECT COUNT(*) AS total, "
                "SUM(CASE WHEN intent IS NULL THEN 1 ELSE 0 END) AS unknown, "
                "COUNT(DISTINCT session_id) AS sessions "
                "FROM messages WHERE theme = ? AND sender = 'user'", (theme,)).fetchone()
        total, unknown = r["total"] or 0, r["unknown"] or 0
        pct = round(100 * (total - unknown) / total, 1) if total else 0.0
        return {"total": total, "unknown": unknown, "recognized_pct": pct,
                "sessions": r["sessions"] or 0}
