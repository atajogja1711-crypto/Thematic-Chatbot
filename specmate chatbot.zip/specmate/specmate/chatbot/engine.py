"""Mesin chatbot rule-based: praproses -> skor kemiripan -> keputusan -> jawaban.
Modul ini sengaja TIDAK mengimpor Flask supaya bisa diuji dan dijalankan di terminal."""
import json
import random
import re
from datetime import datetime
from difflib import SequenceMatcher
from pathlib import Path

THRESHOLD = 0.45  # skor minimum agar intent dianggap cocok

# Frasa multi-kata diganti SEBELUM tanda baca dibuang.
PHRASES = {
    "kartu grafis": "gpu", "patah-patah": "stuttering", "patah patah": "stuttering",
    "rata kanan": "maksimal", "refresh rate": "refreshrate", "frame rate": "fps",
    "frame drop": "fps drop", "nge-lag": "lag", "power supply": "psu", "core i": "i",
}

# Kata tidak baku / sinonim -> bentuk baku (boleh jadi lebih dari satu kata).
NORMALISASI = {
    "gmn": "bagaimana", "gimana": "bagaimana", "bgmn": "bagaimana", "brp": "berapa",
    "vga": "gpu", "prosesor": "cpu", "processor": "cpu", "mobo": "motherboard",
    "mainboard": "motherboard", "nggak": "tidak", "gak": "tidak", "ga": "tidak",
    "ngga": "tidak", "tdk": "tidak", "ngelag": "lag", "lagging": "lag",
    "jt": "juta", "jutaan": "juta", "yg": "yang", "dgn": "dengan", "utk": "untuk",
    "wattage": "watt", "overheat": "panas", "stutter": "stuttering",
    "bandingin": "bandingkan", "kompatibel": "kompatibilitas", "compatible": "kompatibilitas",
}

STOPWORDS = {
    "yang", "di", "ke", "dari", "dong", "nih", "sih", "kak", "lu", "gue", "gw", "ya",
    "deh", "aja", "itu", "ini", "mau", "untuk", "dengan", "buat", "tidak", "bro",
    "bang", "loh", "kan", "pas", "saat", "bisa", "dan", "atau", "sama", "kalau",
}


def preprocess(teks):
    """Kalimat mentah -> daftar token seragam."""
    teks = teks.lower()
    for k, v in PHRASES.items():
        teks = teks.replace(k, v)
    teks = re.sub(r"[^a-z0-9\s]", " ", teks)
    tokens = []
    for kata in teks.split():
        for k in NORMALISASI.get(kata, kata).split():
            if k and k not in STOPWORDS:
                tokens.append(k)
    return tokens


def similarity(a, b):
    """Skor 0..1 = 0,4*Jaccard + 0,3*Fuzzy + 0,3*Cakupan (a=pesan, b=pola)."""
    if not a or not b:
        return 0.0
    sa, sb = set(a), set(b)
    jaccard = len(sa & sb) / len(sa | sb)
    fuzzy = SequenceMatcher(None, " ".join(a), " ".join(b)).ratio()
    cakupan = len(sa & sb) / len(sb)
    return 0.4 * jaccard + 0.3 * fuzzy + 0.3 * cakupan


def validate_theme(theme):
    """Kembalikan daftar kesalahan (kosong = tema valid)."""
    errs = []
    for key in ("id", "bot_name", "title", "greeting", "fallback", "suggestions", "intents"):
        if key not in theme:
            errs.append(f"kunci '{key}' tidak ada")
    for it in theme.get("intents", []):
        tag = it.get("tag", "?")
        if not it.get("patterns"):
            errs.append(f"intent '{tag}' tidak punya patterns")
        if len(it.get("responses", [])) < 1:
            errs.append(f"intent '{tag}' tidak punya responses")
    return errs


def load_themes(folder):
    themes = {}
    for f in sorted(Path(folder).glob("*.json")):
        t = json.loads(f.read_text(encoding="utf-8"))
        errs = validate_theme(t)
        if errs:
            raise ValueError(f"{f.name}: " + "; ".join(errs))
        themes[t["id"]] = t
    return themes


class ChatbotEngine:
    def __init__(self, theme, threshold=THRESHOLD):
        self.theme = theme
        self.threshold = threshold
        self._responses = {i["tag"]: i["responses"] for i in theme["intents"]}
        self._patterns = [(i["tag"], p, preprocess(p))
                          for i in theme["intents"] for p in i["patterns"]]

    def explain(self, pesan, k=3):
        """k kandidat intent teratas (skor terbaik per intent) beserta pola pemenangnya."""
        tokens = preprocess(pesan)
        best = {}
        for tag, pola, ptok in self._patterns:
            s = similarity(tokens, ptok)
            if tag not in best or s > best[tag]["score"]:
                best[tag] = {"intent": tag, "score": round(s, 4), "pattern": pola}
        top = sorted(best.values(), key=lambda x: x["score"], reverse=True)[:k]
        for c in top:
            c["passed"] = c["score"] >= self.threshold
        return top

    def classify(self, pesan):
        """(tag, skor); tag None bila skor tertinggi di bawah ambang."""
        top = self.explain(pesan, 1)
        if not top:
            return None, 0.0
        c = top[0]
        return (c["intent"] if c["passed"] else None), c["score"]

    def _isi_placeholder(self, teks):
        now = datetime.now()
        return (teks.replace("{waktu}", now.strftime("%H:%M"))
                    .replace("{tanggal}", now.strftime("%d-%m-%Y"))
                    .replace("{nama_bot}", self.theme["bot_name"]))

    def greeting(self):
        return self._isi_placeholder(self.theme["greeting"])

    def reply(self, pesan):
        tag, skor = self.classify(pesan)
        if tag is None:
            teks = random.choice(self.theme["fallback"])
        else:
            teks = random.choice(self._responses[tag])
        return {"reply": self._isi_placeholder(teks), "intent": tag, "score": round(skor, 4)}
