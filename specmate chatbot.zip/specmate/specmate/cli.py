"""Coba chatbot di terminal: python cli.py --debug"""
import argparse
from pathlib import Path

from chatbot.engine import ChatbotEngine, load_themes

ap = argparse.ArgumentParser()
ap.add_argument("--tema", default="hardware")
ap.add_argument("--debug", action="store_true", help="tampilkan 3 kandidat + skor")
args = ap.parse_args()

theme = load_themes(Path(__file__).parent / "themes")[args.tema]
bot = ChatbotEngine(theme)
print(f"{theme['bot_name']}: {bot.greeting()}\n(ketik 'keluar' untuk berhenti)\n")
while True:
    pesan = input("Anda: ").strip()
    if pesan.lower() == "keluar":
        break
    if not pesan:
        continue
    r = bot.reply(pesan)
    print(f"Bot : {r['reply']}")
    if args.debug:
        print(f"      [intent: {r['intent']} | skor {r['score']:.2f}]")
        for c in bot.explain(pesan):
            print(f"      - {c['intent']:<18}{c['score']:.2f}  pola: \"{c['pattern']}\"")
    print()
